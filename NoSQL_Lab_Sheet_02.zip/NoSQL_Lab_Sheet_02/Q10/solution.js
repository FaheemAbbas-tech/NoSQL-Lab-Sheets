// Q10: MongoDB sharding demonstration
// IMPORTANT: These commands require a pre-configured MongoDB sharded cluster
// with mongos, config servers and at least two shards. A standalone mongod
// cannot distribute data across shards.

sh.enableSharding("CollegeDB");
use("CollegeDB");

db.Students.createIndex({Student_ID: 1});
sh.shardCollection("CollegeDB.Students", {Student_ID: 1});

// Create at least 20 sample records
for (let i = 1; i <= 20; i++) {
  db.Students.insertOne({
    Student_ID: i,
    Name: i === 1 ? "Faheem Abbas" : "Student" + i,
    Course: "BCA",
    Semester: 5,
    Marks: 70 + (i % 30)
  });
}

// Verify inserted data and sharding status
db.Students.countDocuments();
sh.status();

// The shard key Student_ID determines how documents are partitioned.
// In a real cluster, inspect sh.status() to view shard and chunk distribution.
