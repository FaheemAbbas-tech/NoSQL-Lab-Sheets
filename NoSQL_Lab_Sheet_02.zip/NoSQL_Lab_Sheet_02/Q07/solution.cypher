// Q7: Student-Course relationship graph in Neo4j

// Create three courses
CREATE (:Course {Course_ID:'C01', Name:'BCA'});
CREATE (:Course {Course_ID:'C02', Name:'MCA'});
CREATE (:Course {Course_ID:'C03', Name:'BBA'});

// Create five students and connect them to courses
CREATE (s:Student {Student_ID:101, Name:'Faheem Abbas', Semester:5});
CREATE (s:Student {Student_ID:102, Name:'Aman Khan', Semester:5});
CREATE (s:Student {Student_ID:103, Name:'Sara Ali', Semester:5});
CREATE (s:Student {Student_ID:104, Name:'Rohan Sharma', Semester:5});
CREATE (s:Student {Student_ID:105, Name:'Ayesha Noor', Semester:5});

MATCH (s:Student {Student_ID:101}), (c:Course {Course_ID:'C01'})
CREATE (s)-[:ENROLLED_IN]->(c);
MATCH (s:Student {Student_ID:102}), (c:Course {Course_ID:'C01'})
CREATE (s)-[:ENROLLED_IN]->(c);
MATCH (s:Student {Student_ID:103}), (c:Course {Course_ID:'C02'})
CREATE (s)-[:ENROLLED_IN]->(c);
MATCH (s:Student {Student_ID:104}), (c:Course {Course_ID:'C03'})
CREATE (s)-[:ENROLLED_IN]->(c);
MATCH (s:Student {Student_ID:105}), (c:Course {Course_ID:'C01'})
CREATE (s)-[:ENROLLED_IN]->(c);

// Display all students
MATCH (s:Student) RETURN s;

// Find students enrolled in BCA
MATCH (s:Student)-[:ENROLLED_IN]->(c:Course {Name:'BCA'})
RETURN s.Name;

// Display courses taken by Faheem Abbas
MATCH (s:Student {Student_ID:101})-[:ENROLLED_IN]->(c:Course)
RETURN c.Name;

// Add a relationship
MATCH (s:Student {Student_ID:101}), (c:Course {Course_ID:'C02'})
CREATE (s)-[:ENROLLED_IN]->(c);

// Remove that relationship
MATCH (s:Student {Student_ID:101})-[r:ENROLLED_IN]->(c:Course {Course_ID:'C02'})
DELETE r;
