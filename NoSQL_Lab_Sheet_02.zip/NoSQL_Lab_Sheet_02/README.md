# NoSQL Database Design — Lab Sheet 2

**Student:** Faheem Abbas  
**Course:** BCA  
**Semester:** 5  
**University:** COER University

This folder contains solutions for all 15 questions from the original Lab Sheet 2 PDF.

## Folder structure
- `Q01` to `Q15`: Individual question solutions.
- `Lab Sheet 2 - Original.pdf`: Original question sheet supplied for this lab.

## Software / tools used
- MySQL
- MongoDB Shell (`mongosh`)
- Redis CLI
- Apache Cassandra (`cqlsh`)
- Apache HBase Shell
- Neo4j Browser / Cypher
- MongoDB server tools (`mongod`, `mongosh`, `mongos`, `rs.status()`)

## Important execution notes
- Run each solution using the shell or database named in that question.
- Distributed demonstrations (sharding, replica sets, Cassandra multi-node) require a correctly configured multi-node/sharded environment. A standalone local database cannot demonstrate real data distribution or replication.
- Some commands depend on database version and local configuration.
- MongoDB `mapReduce` is deprecated in MongoDB 5.0 and later; it is included because the lab asks specifically for MapReduce.

## Sample data
The sample student dataset uses the name **Faheem Abbas** and fictional sample classmates/records. Replace sample records only if your instructor requires different data.
