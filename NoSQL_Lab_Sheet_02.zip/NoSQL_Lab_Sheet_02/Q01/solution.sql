-- Q1: Create Student table in MySQL and insert five records.
CREATE DATABASE CollegeDB;
USE CollegeDB;

CREATE TABLE Student (
    Student_ID INT PRIMARY KEY,
    Name VARCHAR(60),
    Course VARCHAR(40),
    Semester INT,
    Marks DECIMAL(5,2)
);

INSERT INTO Student VALUES
(101, 'Faheem Abbas', 'BCA', 5, 85),
(102, 'Aman Khan', 'BCA', 5, 78),
(103, 'Sara Ali', 'BCA', 5, 91),
(104, 'Rohan Sharma', 'BCA', 5, 74),
(105, 'Ayesha Noor', 'BCA', 5, 88);

SELECT * FROM Student;

-- Equivalent MongoDB documents (run in mongosh):
-- use CollegeDB
-- db.Students.insertMany([
--   {Student_ID:101, Name:"Faheem Abbas", Course:"BCA", Semester:5, Marks:85},
--   {Student_ID:102, Name:"Aman Khan", Course:"BCA", Semester:5, Marks:78},
--   {Student_ID:103, Name:"Sara Ali", Course:"BCA", Semester:5, Marks:91},
--   {Student_ID:104, Name:"Rohan Sharma", Course:"BCA", Semester:5, Marks:74},
--   {Student_ID:105, Name:"Ayesha Noor", Course:"BCA", Semester:5, Marks:88}
-- ])
-- db.Students.find()

-- Comparison:
-- RDBMS: fixed table schema, rows and columns, SQL, strong relational constraints.
-- MongoDB: flexible document schema, BSON documents, field-based queries,
-- and easier horizontal scaling through sharding.
