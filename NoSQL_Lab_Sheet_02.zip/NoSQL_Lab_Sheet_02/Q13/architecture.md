# Q13: NoSQL Architecture Combining Sharding and Replication

## Architecture
```text
                  Application
                       |
                 Query Router
                       |
          +------------+------------+
          |                         |
       Shard 1                   Shard 2
     +---------+               +---------+
     | Primary |               | Primary |
     +----+----+               +----+----+
          |                         |
     +----v----+               +----v----+
     | Replica |               | Replica |
     +---------+               +---------+
```

## Demonstration concept
- Create multiple shards to divide the dataset horizontally.
- Configure a replica set for each shard.
- Insert sample student documents through `mongos`.
- Use `sh.status()` to verify shard distribution.
- Use `rs.status()` while connected to each shard replica set to verify replica members.

## Example sharding commands (on a configured MongoDB sharded cluster)
```javascript
sh.enableSharding("CollegeDB");
use("CollegeDB");
db.Students.createIndex({Student_ID: 1});
sh.shardCollection("CollegeDB.Students", {Student_ID: 1});

for (let i = 1; i <= 20; i++) {
  db.Students.insertOne({
    Student_ID: i,
    Name: i === 1 ? "Faheem Abbas" : "Student" + i,
    Course: "BCA",
    Semester: 5,
    Marks: 80
  });
}
sh.status();
```

## Benefits
- Sharding provides horizontal scalability by distributing data.
- Replication provides availability and fault tolerance through copies of data.
- If one replica member fails, an eligible member may take over.
- If an entire shard is unavailable and has no reachable replica, its data may be unavailable.
