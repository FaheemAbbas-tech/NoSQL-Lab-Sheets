// Q2: MongoDB Student Database
use("CollegeDB");

db.Students.insertMany([
  {Student_ID:101, Name:"Faheem Abbas", Course:"BCA", Semester:5, Marks:85},
  {Student_ID:102, Name:"Aman Khan", Course:"BCA", Semester:5, Marks:78},
  {Student_ID:103, Name:"Sara Ali", Course:"BCA", Semester:5, Marks:91},
  {Student_ID:104, Name:"Rohan Sharma", Course:"BCA", Semester:5, Marks:74},
  {Student_ID:105, Name:"Ayesha Noor", Course:"BCA", Semester:5, Marks:88}
]);

// 1. Display all documents
db.Students.find();

// 2. Find students from a particular course
db.Students.find({Course:"BCA"});

// 3. Update marks of a student
db.Students.updateOne(
  {Student_ID:101},
  {$set:{Marks:90}}
);

// 4. Delete one student (example: ID 105)
db.Students.deleteOne({Student_ID:105});

// 5. Count total students
db.Students.countDocuments();
