# Q15: Database Distribution Models

## 1. Single Server
```text
Application ---> One Database Server
```
- Data: Stored on one server.
- Failure: Server failure can make the database unavailable.
- Advantage: Simple to install and manage.
- Limitation: Limited scalability and single point of failure.
- Application: Small college application.

## 2. Sharding
```text
Application ---> Router ---> Shard 1
                       `---> Shard 2
```
- Data: Divided across multiple shards using a shard key.
- Failure: A shard failure can affect access to its data if no replica is available.
- Advantage: Horizontal scalability.
- Limitation: More complex setup and shard-key design.
- Application: Large e-commerce catalogue.

## 3. Master-Slave (Primary-Secondary) Replication
```text
Application ---> Primary
                    |
             +------+------+
             |             |
          Secondary 1  Secondary 2
```
- Data: Primary accepts writes; secondary nodes replicate changes.
- Failure: An eligible secondary may be elected primary in a replica-set system.
- Advantage: Availability and read scaling.
- Limitation: Replication lag can occur.
- Application: Banking/reporting system (with suitable consistency design).

## 4. Peer-to-Peer Replication
```text
       Node 1 <----> Node 2
          ^             |
          |             v
              Node 3
```
- Data: Distributed among equal nodes; replicas are maintained according to the database strategy.
- Failure: Other replicas can continue serving requests depending on consistency level and replication factor.
- Advantage: No fixed master; distributed availability.
- Limitation: Consistency and conflict handling can be more complex.
- Application: Globally distributed activity/event data using Cassandra.

## 5. Sharding + Replication
```text
Application ---> Router
                  |       |
                Shard 1  Shard 2
                  |       |
                Replica  Replica
```
- Data: First partitioned into shards, then replicated within each shard.
- Failure: Replica election/recovery can protect against an individual node failure; total shard loss remains a risk.
- Advantage: Scalability plus fault tolerance.
- Limitation: Higher operational complexity and resource cost.
- Application: Large-scale online shopping platform.

## Conclusion
Single-server architecture is simplest. Sharding distributes data for scale.
Replication maintains copies for availability. Combining sharding and replication
can provide both horizontal scaling and fault tolerance.
