// Q3: MongoDB Orders with embedded customer and product data
use("CollegeDB");

db.Orders.insertMany([
  {Order_ID:1, Customer:{Name:"Faheem Abbas", City:"Roorkee"},
   Products:[{Name:"Keyboard", Price:800, Quantity:1},{Name:"Mouse", Price:400, Quantity:2}]},
  {Order_ID:2, Customer:{Name:"Aman Khan", City:"Haridwar"},
   Products:[{Name:"Monitor", Price:9000, Quantity:1}]},
  {Order_ID:3, Customer:{Name:"Sara Ali", City:"Roorkee"},
   Products:[{Name:"Headphones", Price:1200, Quantity:1}]},
  {Order_ID:4, Customer:{Name:"Rohan Sharma", City:"Delhi"},
   Products:[{Name:"SSD", Price:2500, Quantity:2}]},
  {Order_ID:5, Customer:{Name:"Ayesha Noor", City:"Meerut"},
   Products:[{Name:"Webcam", Price:1800, Quantity:1}]}
]);

// 1. Inserted five orders; display them
db.Orders.find();

// 2. Orders of a particular customer
db.Orders.find({"Customer.Name":"Faheem Abbas"});

// 3. Update quantity of a product in Order 1
db.Orders.updateOne(
  {Order_ID:1, "Products.Name":"Mouse"},
  {$set:{"Products.$.Quantity":3}}
);

// 4. Calculate total order amount using aggregation
db.Orders.aggregate([
  {$unwind:"$Products"},
  {$group:{
    _id:"$Order_ID",
    Customer:{$first:"$Customer.Name"},
    Total:{$sum:{$multiply:["$Products.Price","$Products.Quantity"]}}
  }},
  {$sort:{_id:1}}
]);

// 5. Display orders above a specified amount (e.g. 2000)
db.Orders.aggregate([
  {$unwind:"$Products"},
  {$group:{_id:"$Order_ID", Total:{$sum:{$multiply:["$Products.Price","$Products.Quantity"]}}}},
  {$match:{Total:{$gt:2000}}}
]);
