# Q12: Peer-to-Peer Replication using Cassandra

Cassandra uses a peer-to-peer architecture. Nodes have equal roles; there is no
permanent master node. This demonstration requires multiple Cassandra nodes
configured in the same cluster (for example, using a local multi-node setup).

## Create keyspace
```sql
CREATE KEYSPACE CollegeDB
WITH replication = {
  'class': 'NetworkTopologyStrategy',
  'datacenter1': 2
};

USE CollegeDB;

CREATE TABLE Students (
  Student_ID int PRIMARY KEY,
  Name text,
  Course text,
  Semester int,
  Marks float
);

INSERT INTO Students (Student_ID, Name, Course, Semester, Marks)
VALUES (101, 'Faheem Abbas', 'BCA', 5, 85);

SELECT * FROM Students;
```

## Verify cluster
Run in `nodetool`:
```bash
nodetool status
```

The status command lists nodes in the cluster. With replication factor 2,
Cassandra stores replicas on two nodes according to its replication strategy.

## Difference from master-slave
In master-slave replication, one primary handles writes and replicas follow it.
In Cassandra peer-to-peer architecture, nodes are equal and coordinate requests.
