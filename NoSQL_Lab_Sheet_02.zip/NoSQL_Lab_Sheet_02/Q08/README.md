# Q8: Comparison of MongoDB, Cassandra and Neo4j

Use the same student dataset in all three databases.

| Feature | MongoDB | Cassandra | Neo4j |
|---|---|---|---|
| Data model | Document | Wide-column | Graph |
| Storage structure | BSON documents in collections | Rows in partitioned tables | Nodes and relationships |
| Query method | MongoDB Query API | CQL | Cypher |
| Scalability | Horizontal scaling using sharding | Distributed horizontal scaling | Clustering and distributed deployment options |
| Suitable applications | Content/catalog applications | High-volume distributed data | Social networks and connected data |

Example student:
Student_ID: 101, Name: Faheem Abbas, Course: BCA, Semester: 5, Marks: 85.

Conclusion: MongoDB is suitable for flexible document data, Cassandra for high-volume distributed workloads, and Neo4j for highly connected data.
