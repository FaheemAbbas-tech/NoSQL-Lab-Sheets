// Q14: MapReduce on a student dataset in MongoDB
// Note: MongoDB's mapReduce command is deprecated in MongoDB 5.0+.
// This is the MapReduce-style demonstration requested in the lab sheet.
// For new applications, use aggregation pipelines.

use("CollegeDB");

db.StudentMarks.insertMany([
  {Student_ID:101, Name:"Faheem Abbas", Course:"BCA", Marks:85},
  {Student_ID:102, Name:"Aman Khan", Course:"BCA", Marks:78},
  {Student_ID:103, Name:"Sara Ali", Course:"BCA", Marks:91},
  {Student_ID:104, Name:"Rohan Sharma", Course:"BCA", Marks:74},
  {Student_ID:105, Name:"Ayesha Noor", Course:"MCA", Marks:88},
  {Student_ID:106, Name:"Imran Khan", Course:"MCA", Marks:82}
]);

var mapFunction = function () {
  emit(this.Course, {count: 1, totalMarks: this.Marks});
};

var reduceFunction = function (course, values) {
  var result = {count: 0, totalMarks: 0};
  values.forEach(function (value) {
    result.count += value.count;
    result.totalMarks += value.totalMarks;
  });
  return result;
};

db.StudentMarks.mapReduce(
  mapFunction,
  reduceFunction,
  {out: "CourseSummary"}
);

// Display reduced values and calculate average marks
db.CourseSummary.find().forEach(function (doc) {
  print({
    Course: doc._id,
    StudentCount: doc.value.count,
    AverageMarks: doc.value.totalMarks / doc.value.count
  });
});
