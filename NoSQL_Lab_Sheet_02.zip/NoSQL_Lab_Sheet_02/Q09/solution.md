# Q9: Deploy a NoSQL database on a single server/local machine

This demonstration uses MongoDB Community Server on one local machine.

## Steps
1. Install MongoDB Community Server and MongoDB Shell (`mongosh`) for the operating system.
2. Start the MongoDB service. On Windows, use the MongoDB service installed by the installer, or start `mongod` with a valid data directory.
3. Open `mongosh`.
4. Run the following commands:

```javascript
use CollegeDB
db.createCollection("Students")

db.Students.insertMany([
  {Student_ID:101, Name:"Faheem Abbas", Course:"BCA", Semester:5, Marks:85},
  {Student_ID:102, Name:"Aman Khan", Course:"BCA", Semester:5, Marks:78},
  {Student_ID:103, Name:"Sara Ali", Course:"BCA", Semester:5, Marks:91}
])

// Read
db.Students.find()

// Update
db.Students.updateOne({Student_ID:101}, {$set:{Marks:90}})

// Delete
db.Students.deleteOne({Student_ID:103})

// Verify
db.Students.find()
db.Students.countDocuments()
```

## Expected result
The database and collection are created on the local MongoDB server. Insert, find, update and delete operations execute successfully.

Note: A single-server deployment demonstrates local database operations; it is not a sharded or replicated cluster.
